use stremio_core::runtime::msg::Event;

pub enum AndroidEvent {
    CoreEvent(Event),
}
