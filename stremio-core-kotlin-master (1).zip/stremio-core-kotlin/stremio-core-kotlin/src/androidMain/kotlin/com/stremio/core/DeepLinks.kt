package com.stremio.core

class LibraryDeepLinks(
    val library: String,
)
