rootProject.name = "stremio-core-kotlin"

include("src")

pluginManagement {
    repositories {
        google()
        gradlePluginPortal()
        mavenCentral()
    }
}
